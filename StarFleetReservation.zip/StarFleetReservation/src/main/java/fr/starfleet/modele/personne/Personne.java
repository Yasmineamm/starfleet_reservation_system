package fr.starfleet.modele.personne;

public abstract class Personne{
    private String nom;
    private String prenom;
    private String identifiant;

    // Constructeur
    public Personne(String nom, String prenom, String identifiant){
        this.nom = nom;
        this.prenom = prenom;
        this.identifiant = identifiant;
    }
    //getters and setters
    public String getnom(){
        return nom;
    }
    public void setNom(String nom){
        this.nom = nom;
    }
    public String getprenom(){
        return prenom;
    }
    public void setprenom(String prenom){
        this.prenom = prenom;
    }
    public String getidentifiant(){
        return identifiant;
    }
    public void setidentifiant(String identifiant){
        this.identifiant = identifiant;
    }

    // Méthode abstraite 
    public abstract String getDescription();
}