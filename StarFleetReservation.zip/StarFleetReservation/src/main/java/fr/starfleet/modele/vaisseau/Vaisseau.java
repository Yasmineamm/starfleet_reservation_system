package fr.starfleet.modele.vaisseau;

import java.util.List;
import java.util.ArrayList;
import fr.starfleet.modele.mission.Mission;

public class Vaisseau {
    private String nom;
    private String immatriculation;
    private int capaciteMax;
    private List<Mission> missions;

    public Vaisseau(String nom, String immatriculation, int capaciteMax) {
        this.nom = nom;
        this.immatriculation = immatriculation;
        this.capaciteMax = capaciteMax;
        this.missions = new ArrayList<>();
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getImmatriculation() {
        return immatriculation;
    }
    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }
    public int getCapaciteMax() {
        return capaciteMax;
    }
    public void setCapaciteMax(int capaciteMax) {
        this.capaciteMax = capaciteMax;
    }
    public List<Mission> getMissions() {
        return missions;
    }

    //Méthodes pour gerer les missions
    public void ajouterMission(Mission mission) {
        this.missions.add(mission);
    }
    
    public void modifierVaisseau(String nom, int capacite) {
        this.nom = nom;
        this.capaciteMaximale = capacite;
    }
    
    public void supprimerMission(Mission mission) {
        missions.remove(mission);
    }
    
    public List<Mission> getMissionsEnCours() {
        List<Mission> missionsEnCours = new ArrayList<>();
        for (Mission mission : missions) {
            if (!mission.isTerminee()) {
                missionsEnCours.add(mission);
            }
        }
        return missionsEnCours;
    }
}
