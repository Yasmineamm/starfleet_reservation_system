package fr.starfleet.modele.personne;

public class Officier extends Personne {
    private String rang;
    private String specialite;

    public Officier(String nom, String prenom, String identifiant, String rang, String specialte){
        super(nom, prenom, identifiant);
        this.rang = rang;
        this.specialite = specialte;
    }

    public String getrang(){
        return rang;
    }
    public void setrang(String rang){
        this.rang = rang;
    }
    public String getspecialite(){
        return specialite;
    }
    public void setspecialite(String specialite){
        this.specialite = specialite;
    }

    //implémenter la méthode getDescription
    @Override
    public String getDescription() {
        return "Officier StarFleet : "+ getrang() +" "+ getnom() +" "+ getprenom() +" -> Spécialté : "+ getspecialite();
    }
}
