package fr.starfleet.modele.reservation;

import java.util.Date;
import fr.starfleet.modele.personne.Personne;
import fr.starfleet.modele.mission.Mission;

public class Reservation {
    private String idReservation;
    private Personne passager;
    private Mission mission;
    private Date dateReservation;
    private boolean confirmee;

    // Constructeur
    public Reservation(String idReservation, Personne passager, Mission mission, Date dateReservation) {
        this.idReservation = idReservation;
        this.passager = passager;
        this.mission = mission;
        this.dateReservation = dateReservation;
        this.confirmee = false; // Par défaut, la réservation n'est pas confirmée
    }

    // Getters
    public String getIdReservation() { return idReservation; }
    public Personne getPassager() { return passager; }
    public Mission getMission() { return mission; }
    public Date getDateReservation() { return dateReservation; }
    public boolean isConfirmee() { return confirmee; }

    // Setters
    public void setDateReservation(Date dateReservation) { this.dateReservation = dateReservation; }

    // Méthodes
    public void confirmerReservation() {
        if (!confirmee) {
            confirmee = true;
            System.out.println("Réservation " + idReservation + " confirmée !");
        } else {
            System.out.println("Réservation déjà confirmée.");
        }
    }

    public void afficherReservation() {
        System.out.println("Réservation ID: " + idReservation);
        System.out.println("Passager: " + passager.getnom() + " " + passager.getprenom());
        System.out.println("Mission: " + mission.getCode() + " - " + mission.getDestination());
        System.out.println("Date de réservation: " + dateReservation);
        System.out.println("Confirmée: " + (confirmee ? "Oui" : "Non"));
    }

    public void annulerReservation() {
        if (confirmee) {
            confirmee = false;
            System.out.println("Réservation " + idReservation + " annulée !");
        } else {
            System.out.println("Réservation non confirmée, impossible d'annuler.");
        }
    }
    
}
