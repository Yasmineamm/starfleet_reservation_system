
package fr.starfleet.modele.personne;

public class Civil extends Personne {
    private String planeteOrigine;
    private String motifVoyage;

    public Civil(String nom, String prenom, String identifiant, String planeteOrigine, String motifVoyage){
        super(nom, prenom, identifiant);
        this.planeteOrigine = planeteOrigine;
        this.motifVoyage = motifVoyage;
        }

    public String getplaneteOrigine(){
        return planeteOrigine;
    }
    public void setplaneteOrigine(String planeteOrigine){
        this.planeteOrigine = planeteOrigine;
    }
    public String getmotifVoyage(){
        return motifVoyage;
    }
    public void setmotifVoyage(String motifVoyage){
        this.motifVoyage = motifVoyage;
    }

    @Override 
    public String getDescription(){
        return "Civil " + getnom() + " " + getprenom() + " - Origine : " + planeteOrigine + ", Motif : " + motifVoyage;
    }
}
