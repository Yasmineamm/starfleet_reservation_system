package fr.starfleet.modele.mission;

import java.util.List;
import fr.starfleet.modele.reservation.Reservation;
import fr.starfleet.modele.vaisseau.Vaisseau;
import java.util.ArrayList;
import java.util.Date;

public class Mission {
    private String code;
    private String description;
    private Date dateDepart;
    private Date dateRetour;
    private String destination;
    private Vaisseau vaisseau;
    private List<Reservation> reservations;
    private int capaciteMaximale;   

    public Mission(String code, String description, Date dateDepart, Date dateRetour, 
                   String destination, Vaisseau vaisseau, int capaciteMaximale) {
        this.code = code;
        this.description = description;
        this.dateDepart = dateDepart;
        this.dateRetour = dateRetour;
        this.destination = destination;
        this.vaisseau = vaisseau;
        this.capaciteMaximale = capaciteMaximale;
        this.reservations = new ArrayList<>();
    }

    public String getCode() { return code; }
    public String getDescription() { return description; }
    public Date getDateDepart() { return dateDepart; }
    public Date getDateRetour() { return dateRetour; }
    public String getDestination() { return destination; }
    public Vaisseau getVaisseau() { return vaisseau; }
    public int getCapaciteMaximale() { return capaciteMaximale; }
    public List<Reservation> getReservations() { return reservations; }

    // Ajouter une réservation à la mission
    public boolean ajouterReservation(Reservation reservation) {
        if (reservations.size() < capaciteMaximale) {
            reservations.add(reservation);
            return true;
        } else {
            System.out.println("Capacité maximale atteinte pour cette mission !");
            return false;
        }
    }

    // ajouter isterminee
    public boolean isTerminee() {
        return dateRetour.before(new Date());
    }

    //annuler une réservation
    public boolean annulerReservation(Reservation reservation) {
        if (reservations.contains(reservation)) {
            reservations.remove(reservation);
            return true;
        } else {
            System.out.println("Réservation non trouvée !");
            return false;
        }
    }

    // nombre de place disponible
    public int placesDisponibles() {
        return capaciteMaximale - reservations.size();
    }

    // Affichage des infos de la mission
    public void afficherMission() {
        System.out.println("Mission: " + code + " - " + description);
        System.out.println("Destination: " + destination);
        System.out.println("Date de départ: " + dateDepart);
        System.out.println("Date de retour: " + dateRetour);
        System.out.println("Vaisseau: " + vaisseau.getNom());
        System.out.println("Capacité: " + reservations.size() + "/" + capaciteMaximale);
    }
}
