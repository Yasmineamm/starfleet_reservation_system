package fr.starfleet.systeme;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import fr.starfleet.modele.vaisseau.Vaisseau;
import fr.starfleet.modele.personne.Personne;
import fr.starfleet.modele.mission.Mission;
import fr.starfleet.modele.reservation.Reservation;
import fr.starfleet.util.FileUtil;

public class SystemeReservation {
    private List<Vaisseau> vaisseaux;
    private List<Personne> personnes;
    private List<Mission> missions;
    private List<Reservation> reservations;

    public SystemeReservation() {
        this.vaisseaux = new ArrayList<>();
        this.personnes = new ArrayList<>();
        this.missions = new ArrayList<>();
        this.reservations = new ArrayList<>();
    }

    // Ajouter un vaisseau
    public void ajouterVaisseau(Vaisseau vaisseau) {
        vaisseaux.add(vaisseau);
    }

    // Ajouter une personne (Officier ou Civil)
    public void ajouterPersonne(Personne personne) {
        personnes.add(personne);
    }

    // Créer une mission
    public void creerMission(Mission mission) {
        missions.add(mission);
    }

    // Effectuer une réservation
    public Reservation effectuerReservation(String idPersonne, String codeMission) {
        // Trouver la personne
        Personne passager = null;
        for (Personne p : personnes) {
            if (p.getidentifiant().equalsIgnoreCase(idPersonne)) {
                passager = p;
                break;
            }
        }
        if (passager == null) {
            System.out.println("Personne non trouvée !");
            return null;
        }

        // Trouver la mission
        Mission mission = null;
        for (Mission m : missions) {
            if (m.getCode().equalsIgnoreCase(codeMission)) {
                mission = m;
                break;
            }
        }
        if (mission == null) {
            System.out.println("Mission non trouvée !");
            return null;
        }

        // Créer la réservation
        Reservation reservation = new Reservation("R" + (reservations.size() + 1), passager, mission, new java.util.Date());
        reservations.add(reservation);
        System.out.println("Réservation effectuée pour " + passager.getnom() + " !");
        return reservation;
    }

    // Rechercher des missions par destination
    public List<Mission> rechercherMissions(String destination) {
        List<Mission> resultat = new ArrayList<>();
        for (Mission m : missions) {
            if (m.getDestination().equalsIgnoreCase(destination)) {
                resultat.add(m);
            }
        }
        return resultat;
    }

    // Sauvegarder les données dans un fichier
    public void sauvegarderDonnees(String fichier) {
        FileUtil.sauvegarder(fichier, this);
    }

    // Charger les données depuis un fichier
    public void chargerDonnees(String fichier) {
        SystemeReservation data = (SystemeReservation) FileUtil.charger(fichier);
        if (data != null) {
            this.vaisseaux = data.vaisseaux;
            this.personnes = data.personnes;
            this.missions = data.missions;
            this.reservations = data.reservations;
        }
    }

    public void modifierVaisseau(String immatriculation, String nouveauNom, int nouvelleCapacite) {
        for (Vaisseau v : vaisseaux) {
            if (v.getImmatriculation().equals(immatriculation)) {
                v.modifierVaisseau(nouveauNom, nouvelleCapacite);
                return;
            }
        }
    }
    
    public void supprimerVaisseau(String immatriculation) {
        vaisseaux.removeIf(v -> v.getImmatriculation().equals(immatriculation));
    }
    
}
