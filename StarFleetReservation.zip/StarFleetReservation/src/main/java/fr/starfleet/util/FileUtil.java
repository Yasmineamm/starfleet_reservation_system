package fr.starfleet.util;

import java.io.*;
import java.util.List;

public class FileUtil {
    // Méthode pour sauvegarder un objet dans un fichier
    public static void sauvegarderObjet(String fichier, Object objet) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichier))) {
            oos.writeObject(objet);
            System.out.println("Données sauvegardées avec succès dans " + fichier);
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde des données : " + e.getMessage());
        }
    }

    // Méthode pour charger un objet depuis un fichier
    public static Object chargerObjet(String fichier) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fichier))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur lors du chargement des données : " + e.getMessage());
            return null;
        }
    }
}
