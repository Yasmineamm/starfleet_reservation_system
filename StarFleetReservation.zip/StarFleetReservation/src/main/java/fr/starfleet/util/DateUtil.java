package fr.starfleet.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
    private static final String FORMAT = "dd/MM/yyyy";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMAT);

    // Convertir une chaîne en Date
    public static Date stringToDate(String dateStr) {
        try {
            return dateFormat.parse(dateStr);
        } catch (ParseException e) {
            System.err.println("Format de date invalide : " + dateStr);
            return null;
        }
    }

    // Convertir une Date en chaîne
    public static String dateToString(Date date) {
        return dateFormat.format(date);
    }
}
