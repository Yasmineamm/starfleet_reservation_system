package fr.starfleet.ui;

import fr.starfleet.systeme.SystemeReservation;
import fr.starfleet.modele.vaisseau.Vaisseau;
import fr.starfleet.modele.personne.*;
import fr.starfleet.modele.mission.Mission;
import fr.starfleet.modele.reservation.Reservation;
import fr.starfleet.util.FileUtil;
import java.util.Scanner;
import java.util.List;

public class InterfaceConsole {
    private SystemeReservation systeme;
    private Scanner scanner;

    // Constructeur
    public InterfaceConsole(SystemeReservation systeme) {
        this.systeme = systeme;
        this.scanner = new Scanner(System.in);
    }

    // Méthode principale pour démarrer l'interface
    public void demarrer() {
        boolean continuer = true;
        while (continuer) {
            afficherMenu();
            System.out.print("Votre choix : ");
            int choix = scanner.nextInt();
            scanner.nextLine(); // Consommer la ligne restante
            
            switch (choix) {
                case 1:
                    gererVaisseaux();
                    break;
                case 2:
                    gererPersonnes();
                    break;
                case 3:
                    gererMissions();
                    break;
                case 4:
                    gererReservations();
                    break;
                case 5:
                    sauvegarderDonnees();
                    break;
                case 6:
                    chargerDonnees();
                    break;
                case 0:
                    continuer = false;
                    System.out.println("Fermeture du système...");
                    break;
                default:
                    System.out.println("Option invalide, veuillez réessayer.");
            }
        }
    }

    // Affichage du menu principal
    private void afficherMenu() {
        System.out.println("\n=== Menu Principal ===");
        System.out.println("1. Gérer les vaisseaux");
        System.out.println("2. Gérer les personnes");
        System.out.println("3. Gérer les missions");
        System.out.println("4. Gérer les réservations");
        System.out.println("5. Sauvegarder les données");
        System.out.println("6. Charger les données");
        System.out.println("0. Quitter");
    }

    // Gestion des vaisseaux
    private void gererVaisseaux() {
        System.out.print("Nom du vaisseau : ");
        String nom = scanner.nextLine();
        System.out.print("Immatriculation : ");
        String immatriculation = scanner.nextLine();
        System.out.print("Capacité maximale : ");
        int capacite = scanner.nextInt();
        scanner.nextLine();
        
        Vaisseau vaisseau = new Vaisseau(nom, immatriculation, capacite);
        systeme.ajouterVaisseau(vaisseau);
        System.out.println("Vaisseau ajouté avec succès !");
    }

    // Gestion des personnes (Officiers et Civils)
    private void gererPersonnes() {
        System.out.print("Nom : ");
        String nom = scanner.nextLine();
        System.out.print("Prénom : ");
        String prenom = scanner.nextLine();
        System.out.print("Identifiant : ");
        String identifiant = scanner.nextLine();
        System.out.print("Type (1 = Officier, 2 = Civil) : ");
        int type = scanner.nextInt();
        scanner.nextLine();
        
        Personne personne;
        if (type == 1) {
            System.out.print("Rang : ");
            String rang = scanner.nextLine();
            System.out.print("Spécialité : ");
            String specialite = scanner.nextLine();
            personne = new Officier(nom, prenom, identifiant, rang, specialite);
        } else {
            System.out.print("Planète d'origine : ");
            String planete = scanner.nextLine();
            System.out.print("Motif de voyage : ");
            String motif = scanner.nextLine();
            personne = new Civil(nom, prenom, identifiant, planete, motif);
        }
        systeme.ajouterPersonne(personne);
        System.out.println("Personne ajoutée avec succès !");
    }

    // Gestion des missions
    private void gererMissions() {
        System.out.print("Code mission : ");
        String code = scanner.nextLine();
        System.out.print("Description : ");
        String description = scanner.nextLine();
        System.out.print("Destination : ");
        String destination = scanner.nextLine();
        
        List<Vaisseau> vaisseaux = systeme.getVaisseaux();
        if (vaisseaux.isEmpty()) {
            System.out.println("Aucun vaisseau disponible. Veuillez en ajouter un d'abord.");
            return;
        }
        System.out.println("Sélectionnez un vaisseau disponible :");
        for (int i = 0; i < vaisseaux.size(); i++) {
            System.out.println((i + 1) + ". " + vaisseaux.get(i).getNom());
        }
        int choixVaisseau = scanner.nextInt() - 1;
        scanner.nextLine();
        
        Mission mission = new Mission(code, description, destination, vaisseaux.get(choixVaisseau));
        systeme.creerMission(mission);
        System.out.println("Mission créée avec succès !");
    }

    // Gestion des réservations
    private void gererReservations() {
        System.out.print("Identifiant du passager : ");
        String idPersonne = scanner.nextLine();
        System.out.print("Code de la mission : ");
        String codeMission = scanner.nextLine();
        
        Reservation reservation = systeme.effectuerReservation(idPersonne, codeMission);
        if (reservation != null) {
            System.out.println("Réservation effectuée avec succès !");
        } else {
            System.out.println("Échec de la réservation (place disponible ?) !");
        }
    }

    // Sauvegarde des données
    private void sauvegarderDonnees() {
        System.out.print("Nom du fichier de sauvegarde : ");
        String fichier = scanner.nextLine();
        systeme.sauvegarderDonnees(fichier);
        System.out.println("Données sauvegardées avec succès.");
    }

    // Chargement des données
    private void chargerDonnees() {
        System.out.print("Nom du fichier à charger : ");
        String fichier = scanner.nextLine();
        systeme.chargerDonnees(fichier);
        System.out.println("Données chargées avec succès.");
    }
}
