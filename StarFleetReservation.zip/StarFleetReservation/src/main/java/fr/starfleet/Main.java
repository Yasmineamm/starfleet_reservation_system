package fr.starfleet;

import fr.starfleet.modele.personne.*;
import fr.starfleet.modele.vaisseau.Vaisseau;
import fr.starfleet.modele.mission.Mission;
import fr.starfleet.modele.reservation.Reservation;
import fr.starfleet.systeme.SystemeReservation;
import fr.starfleet.util.FileUtil;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Initialisation du système de réservation
        SystemeReservation systeme = new SystemeReservation();

        // 1️⃣ Créer plusieurs vaisseaux
        Vaisseau enterprise = new Vaisseau("USS Enterprise", "NCC-1701", 500);
        Vaisseau voyager = new Vaisseau("USS Voyager", "NCC-74656", 300);
        systeme.ajouterVaisseau(enterprise);
        systeme.ajouterVaisseau(voyager);

        // 2️⃣ Ajouter des officiers et des civils
        Personne picard = new Officier("Picard", "Jean-Luc", "PICARDJ", "Capitaine", "Commandement");
        Personne riker = new Officier("Riker", "William", "RIKERW", "Commander", "Stratégie");
        Personne civilian = new Civil("Doe", "John", "DOEJ", "Terre", "Tourisme");

        systeme.ajouterPersonne(picard);
        systeme.ajouterPersonne(riker);
        systeme.ajouterPersonne(civilian);

        // 3️⃣ Créer des missions
        Mission mission1 = new Mission("M001", "Exploration de Vulcain", new Date(), new Date(), "Vulcain", enterprise, 500);
        Mission mission2 = new Mission("M002", "Délégation diplomatique sur Terre", new Date(), new Date(), "Terre", voyager, 300);
        systeme.creerMission(mission1);
        systeme.creerMission(mission2);

        // 4️⃣ Effectuer des réservations
        Reservation res1 = systeme.effectuerReservation("PICARDJ", "M001");
        Reservation res2 = systeme.effectuerReservation("DOEJ", "M002");

        // 5️⃣ Confirmer ou annuler certaines réservations
        if (res1 != null) {
            res1.confirmer();
        }
        if (res2 != null) {
            res2.annuler();
        }

        // 6️⃣ Afficher les passagers pour chaque mission
        System.out.println("Passagers pour Mission M001 (Vulcain) :");
        for (Reservation r : mission1.getReservations()) {
            System.out.println(r.getPassager().getDescription());
        }

        System.out.println("Passagers pour Mission M002 (Terre) :");
        for (Reservation r : mission2.getReservations()) {
            System.out.println(r.getPassager().getDescription());
        }

        // 7️⃣ Sauvegarder les données dans un fichier
        systeme.sauvegarderDonnees("sauvegarde.dat");

        // 8️⃣ Quitter le programme
        System.out.println("Fin du programme. Redémarrage...");

        // 9️⃣ Relancer le programme et charger les données
        SystemeReservation systemeCharge = new SystemeReservation();
        systemeCharge.chargerDonnees("sauvegarde.dat");

        // 🔟 Vérifier que tout fonctionne toujours après le chargement
        System.out.println("Données après rechargement :");
        systemeCharge.afficherToutesLesDonnees();
    }
}
